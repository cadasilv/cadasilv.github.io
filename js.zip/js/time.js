<SCRIPT LANGUAGE = "JavaScript">
<!--

// Array of day names
var dayNames = new Array("Domingo","Segunda_Feira","Terca_Feira","Quarta_Feira","Quinta_Feira","Sexta_Feira","Sabado");

var monthNames = new Array("Janeiro","Fevereiro","Marco","Abril","Maio","Junho","Julho",
                           "Agosto","Setembro","Outubro","Novembro","Dezembro");

var dt = new Date();
var y  = dt.getYear();

// Y2K compliant
if (y < 1000) y +=1900;

document.write(dayNames[dt.getDay()] + ", " + dt.getDate() + " de " + monthNames[dt.getMonth()] + " de " + y);

    function curTime()
	    {
		var now=new Date()
		var hrs=now.getHours()
		var min=now.getMinutes()
		var sec=now.getSeconds()
		var don="AM"
		if (hrs>=12){ don="PM" }
		if (hrs>12) { hrs-=12 }
		if (hrs==0) { hrs=12 }
		if (hrs<10) { hrs="0"+hrs }
		if (min<10) { min="0"+min }
		if (sec<10) { sec="0"+sec }
		clock.innerHTML=hrs+":"+min+":"+sec+" "+don
		setTimeout("curTime()",1000)
	    }
	-->
// -->
</SCRIPT>
