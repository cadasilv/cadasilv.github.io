var imgArray = [ './pic/fabio1.png', './pic/fabio2.png', './pic/fabio3.png', './pic/fabio4.png', ' ./pic/fabio5.png', ' ./pic/fabio6.png', ' ./pic/fabio7.png']; 
 var curIndex = 0; var imgDuration = 2000; function slideShow() { document.getElementById('image1').src = imgArray[curIndex]; curIndex++; if (curIndex == imgArray.length) { curIndex = 0; } setTimeout("slideShow()", imgDuration); } 
window.onload=slideShow; 




