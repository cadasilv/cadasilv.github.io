var imgArray = [ '../pic/fabio1.png', '../pic/fabio2.png', '../pic/fabio3.png', '../pic/fabio4.png', ' ../pic/fabio5.png', ' ../pic/fabio6.png', ' ../pic/fabio7.png']; 
 var curIndex = 0; var imgDuration = 2000; function slideShow() { document.getElementById('image1').src = imgArray[curIndex]; curIndex++; if (curIndex == imgArray.length) { curIndex = 0; } setTimeout("slideShow()", imgDuration); } 
window.onload=slideShow; 

  function horario() { 

var relogio = document.querySelector("#relogio"); 
var d = new Date(); 
var seg = d.getSeconds(); 
var min = d.getMinutes(); 
var hr = d.getHours(); 
var dia = d.getDate(); 
var mes = d.getMonth(); 
var meses = ["Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]; 
var diaSem = d.getDay(); 
var diasSemana = ["Domingo","Segunda-Feira","Terca-Feira","Quarta-Feira","Quinta-Feira","Sexta-Feira","Sabado"]; 
relogio.innerHTML = diasSemana[diaSem] + ", " + dia + " de " + meses[mes] + ", " +  "<br>" +" Hora certa: " + hr + ":" + min + ":" + seg; }

window.onload = setInterval(horario, 1000);
window.onload=horario;


